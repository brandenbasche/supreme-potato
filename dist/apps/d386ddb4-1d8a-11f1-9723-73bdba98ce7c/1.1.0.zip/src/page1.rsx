<Screen
  id="page1"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle=""
  title="Page 1"
  urlSlug=""
  uuid="6f53dc48-ba68-489d-88b6-26d96724fa8e"
>
  <RESTQuery
    id="query1"
    resourceDisplayName="Cats"
    resourceName="22ec95f2-fbdb-4bb0-93f7-0c3c1b3fdc8d"
  />
  <Frame
    id="$main"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    type="main"
  >
    <Button id="button3" text="Button" />
    <Text id="text2" value="# hello world" verticalAlign="center" />
    <Button id="button1" text="Button" />
    <Button id="button2" text="important button">
      <Event
        id="bbd3a881"
        event="click"
        method="confetti"
        params={{}}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Frame>
</Screen>
